<nav x-data="{ open: false }" class="bg-white border-b border-brand-100">
    <!-- Primary Navigation Menu -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">
            <div class="flex">

                <!-- Logo -->
                <div class="shrink-0 flex items-center">
                    <a href="{{ route('dashboard') }}" class="inline-flex items-center gap-2.5" aria-label="SafeSpace home">
                        <span class="grid place-items-center w-9 h-9 rounded-xl bg-brand-700 text-white shadow-sm">
                            <svg viewBox="0 0 24 24" fill="none" class="w-5 h-5" aria-hidden="true">
                                <path d="M12 21s-7.2-4.1-7.2-10V5.5L12 3l7.2 2.5V11c0 5.9-7.2 10-7.2 10Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/>
                                <path d="M8.1 12.2h2l1.2-2.3 1.5 4 1.1-1.8h2" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </span>
                        <span class="text-lg font-extrabold tracking-tight text-brand-700">Safe<span class="text-brand-400">Space</span></span>
                    </a>
                </div>

                <!-- Navigation Links -->
                <div class="hidden space-x-6 sm:-my-px sm:ms-10 sm:flex">
                    <x-nav-link :href="route('dashboard')" :active="request()->routeIs('dashboard') || request()->routeIs('counselor.dashboard') || request()->routeIs('student.home')">
                        {{ __('Dashboard') }}
                    </x-nav-link>

                    @if (auth()->user()->isCounselor())
                        <x-nav-link :href="route('counselor.queue')" :active="request()->routeIs('counselor.queue')">Queue</x-nav-link>
                        <x-nav-link :href="route('counselor.reports')" :active="request()->routeIs('counselor.reports*')">Reports</x-nav-link>
                        <x-nav-link :href="route('counselor.students')" :active="request()->routeIs('counselor.students*')">Students</x-nav-link>
                        <x-nav-link :href="route('counselor.keywords')" :active="request()->routeIs('counselor.keywords*')">Keywords</x-nav-link>
                        <x-nav-link :href="route('counselor.audit')" :active="request()->routeIs('counselor.audit')">Audit Log</x-nav-link>
                    @else
                        <x-nav-link :href="route('student.report.create')" :active="request()->routeIs('student.report.*')">Report</x-nav-link>
                        <x-nav-link :href="route('student.reports.index')" :active="request()->routeIs('student.reports.*')">My Reports</x-nav-link>
                    @endif
                </div>
            </div>

            <!-- Settings Dropdown -->
            <div class="hidden sm:flex sm:items-center sm:ms-6">
                @if (auth()->user()->isCounselor())
                    <x-notification-bell />
                @endif

                <x-dropdown align="right" width="48">
                    <x-slot name="trigger">
                        <button class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-600 bg-white hover:text-brand-700 focus:outline-none transition ease-in-out duration-150">
                            <div>{{ Auth::user()->name }}</div>
                            <div class="ms-1">
                                <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                </svg>
                            </div>
                        </button>
                    </x-slot>

                    <x-slot name="content">
                        <x-dropdown-link :href="route('profile.edit')">
                            {{ __('Profile') }}
                        </x-dropdown-link>

                        <!-- Authentication -->
                        <form method="POST" action="{{ route('logout') }}">
                            @csrf
                            <x-dropdown-link :href="route('logout')"
                                    onclick="event.preventDefault(); this.closest('form').submit();">
                                {{ __('Log Out') }}
                            </x-dropdown-link>
                        </form>
                    </x-slot>
                </x-dropdown>
            </div>

            <!-- Hamburger -->
            <div class="-me-2 flex items-center sm:hidden">
                <button @click="open = ! open" class="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-brand-700 hover:bg-brand-50 focus:outline-none transition duration-150 ease-in-out">
                    <svg class="h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                        <path :class="{'hidden': open, 'inline-flex': ! open }" class="inline-flex" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                        <path :class="{'hidden': ! open, 'inline-flex': open }" class="hidden" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
        </div>
    </div>

    <!-- Responsive Navigation Menu -->
    <div :class="{'block': open, 'hidden': ! open}" class="hidden sm:hidden">
        <div class="pt-2 pb-3 space-y-1">
            <x-responsive-nav-link :href="route('dashboard')" :active="request()->routeIs('dashboard') || request()->routeIs('counselor.dashboard') || request()->routeIs('student.home')">
                {{ __('Dashboard') }}
            </x-responsive-nav-link>

            @if (auth()->user()->isCounselor())
                <x-responsive-nav-link :href="route('counselor.queue')" :active="request()->routeIs('counselor.queue')">Queue</x-responsive-nav-link>
                <x-responsive-nav-link :href="route('counselor.reports')" :active="request()->routeIs('counselor.reports*')">Reports</x-responsive-nav-link>
                <x-responsive-nav-link :href="route('counselor.students')" :active="request()->routeIs('counselor.students*')">Students</x-responsive-nav-link>
                <x-responsive-nav-link :href="route('counselor.keywords')" :active="request()->routeIs('counselor.keywords*')">Keywords</x-responsive-nav-link>
                <x-responsive-nav-link :href="route('counselor.audit')" :active="request()->routeIs('counselor.audit')">Audit Log</x-responsive-nav-link>
            @else
                <x-responsive-nav-link :href="route('student.report.create')" :active="request()->routeIs('student.report.*')">Report</x-responsive-nav-link>
                <x-responsive-nav-link :href="route('student.reports.index')" :active="request()->routeIs('student.reports.*')">My Reports</x-responsive-nav-link>
            @endif
        </div>

        <!-- Responsive Settings Options -->
        <div class="pt-4 pb-1 border-t border-brand-100">
            <div class="px-4">
                <div class="font-medium text-base text-ink">{{ Auth::user()->name }}</div>
                <div class="font-medium text-sm text-gray-500">{{ Auth::user()->email ?? 'LRN ' . Auth::user()->lrn }}</div>
            </div>

            <div class="mt-3 space-y-1">
                <x-responsive-nav-link :href="route('profile.edit')">
                    {{ __('Profile') }}
                </x-responsive-nav-link>

                <!-- Authentication -->
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <x-responsive-nav-link :href="route('logout')"
                            onclick="event.preventDefault(); this.closest('form').submit();">
                        {{ __('Log Out') }}
                    </x-responsive-nav-link>
                </form>
            </div>
        </div>
    </div>
</nav>